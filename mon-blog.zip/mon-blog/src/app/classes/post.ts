export class Post {
  title: string;
  content: string;
  loveIts = 0 ;
  createdat: Date;
}
