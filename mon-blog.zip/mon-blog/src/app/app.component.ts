import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})



export class AppComponent {
  title = 'mon-blog';

  tab_post = [
    {title:'Mon premier poéme',
      content:'Jusqu\'à la fin des temps, je te caresserais \n' +
        'De mes dix doigts pressés de conquérir ta peau \n' +
        'Tandis que mes lèvres sèmeront à gogo \n' +
        'De tes pieds à ton front, des baisers indolents.\n' +
        '\n' +
        'Et quand au passage, je verrais un frisson \n' +
        'S\'envoler prestement de la zone interdite, \n' +
        'Je ferais un virage, j\'augmenterais le son \n' +
        'Pour le voir s\'agrandir, augmenter son orbite.' ,
      loveIts:0,
      createdat: new Date('06-07-2019 10:30')} ,

    {title:'Mon deuxiéme poéme',
      content:'À tous ceux que la vie n\'a pas épargné, \n' +
        'À tous ceux qui en 2018 ont tout perdu,\n' +
        'Je me joins à vous sans aucune retenue, \n' +
        'Que 2019 vous apporte ce dont vous rêvez.\n' +
        '\n' +
        'À ces personnes qui vivent des tragédies, \n' +
        'Je vous adresse toute ma sympathie : \n' +
        'Une vie reste une vie, belle ou maudite, \n' +
        'Mais toute vie vaut la peine d\'être écrite.\n' +
        '\n' +
        'Mes pensées s\'envolent vers les plus démunis, \n' +
        'Frappés injustement par l\'infamie.\n' +
        'Un amour sans frontières, sans barrières :\n' +
        'Que l\'égoïsme soit banni à tout jamais, \n' +
        'Une bonne année à tous ceux que j\'ai oublié.\n' +
        '\n' +
        'Mes meilleurs vœux vous souhaitant, \n' +
        'En ce jour 2019 premier du nouvel an ; \n' +
        'À toutes et à tous : Bonheur Amour Santé, \n' +
        'Que ces mots pour vous soient exaucés.',
      loveIts:0,
      createdat: new Date('07-15-2019 14:23')} ,

    {title:'Mon troisième poéme',
      content:'Vieux tyran, d\'obscure naissance ; \n' +
        'Brillant et pâle séducteur ; \n' +
        'Subtil et volage enchanteur, \n' +
        'Sujet de trouble et d\'insolence :\n' +
        '\n' +
        'Vaine idole, dont la puissance \n' +
        'Soustrait les cœurs au créateur ; \n' +
        'Métal, de tant de maux l\'auteur ; \n' +
        'Objet de crainte et d\'espérance ;\n' +
        '\n' +
        'Or fatal, tu viens de l\'enfer, \n' +
        'Pour nous faire un siècle de fer, \n' +
        'Dans le riche siècle où nous sommes.\n' +
        '\n' +
        'Mais, ô vertu ; rare trésor ! \n' +
        'Si tu descendais sur les hommes, \n' +
        'On reverrait le siècle d\'or.\n',
      loveIts:0,
      createdat: new Date('08-22-2019 16:28')}
  ];


 constructor() {

}

}
